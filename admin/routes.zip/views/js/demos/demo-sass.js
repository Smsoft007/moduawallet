/*
Name: 			SASS
Written by: 	Okler Themes - (http://www.okler.net)
Theme Version:	7.5.0
*/

(function( $ ) {

	'use strict';

	

}).apply( this, [ jQuery ]);